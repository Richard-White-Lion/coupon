<div class="share-coupon share-<?php echo esc_attr( get_the_ID() ) ?>">
	<?php include( get_theme_file_path( 'includes/share.php' ) ) ?>
	<a href="javascript:;" class="toggle-coupon-share" data-target="share-<?php echo esc_attr( get_the_ID() ) ?>"><span class="icon-close"></span></a>
</div>