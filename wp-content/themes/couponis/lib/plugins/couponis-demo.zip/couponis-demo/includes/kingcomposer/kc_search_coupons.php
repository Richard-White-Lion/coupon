<div class="white-block">
	<div class="white-block-content">
		<div class="widget-title">
			<h4><?php esc_html_e( 'Search Coupons', 'couponis' ) ?></h4>
		</div>
		<?php include( get_theme_file_path( 'includes/coupons-search-box.php' ) ); ?>
	</div>
</div>